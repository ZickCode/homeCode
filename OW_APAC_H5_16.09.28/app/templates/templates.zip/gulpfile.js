// 引入 gulp及组件
var gulp = require('gulp'),
    rev = require('gulp-rev')
    revCollector  = require('gulp-rev-collector'),
    autoprefixer = require('gulp-autoprefixer'),
    less = require('gulp-less'),
    uglify = require('gulp-uglify'),
    connect = require('gulp-connect'),
    concat = require('gulp-concat'),
    cssmin = require('gulp-minify-css'),
    clean = require('gulp-clean'),
    gulpSequence = require('gulp-sequence'),
    replace = require('gulp-replace'),
    htmlmin = require('gulp-htmlmin');

var path = {
  src   : "src/",
  css   : "src/css/",
  js    : "src/js/",
  img   : "src/images/",
  build : "build"
}
 

gulp.task('clean', function () {
    console.log('clean is running')
    return gulp.src('dist/')
        .pipe(clean());
});

gulp.task('jsconcat',function () {
    return gulp.src([
        'src/js/vendor/*.js',
        'src/js/plugins/*.js',
        'src/js/core/*.js'])
        .pipe(concat('all.js'))//合并后的文件名
        .pipe(gulp.dest('output/js'));
});

gulp.task('jsconcat-dev',function () {
    return gulp.src([
        'src/js/vendor/*.js',
        'src/js/plugins/*.js',
        'src/js/core/*.js'
        ])
        .pipe(concat('all.js'))//合并后的文件名
        .pipe(gulp.dest('src/assets/js'));
});


gulp.task('jsmin',function () {
    return gulp.src('output/js/*.js')
        .pipe(uglify())
        .pipe(gulp.dest('output/js/'))
});

// gulp.task('jsRev', function () {
//     return gulp.src('output/js/*.js')
//         .pipe(rev())
//         .pipe(gulp.dest('dist/js'))
//         .pipe(rev.manifest({
//             base: 'dist/css',
//             merge: true // merge with the existing manifest (if one exists)
//         }))
//         .pipe(gulp.dest('output/rev'));
// });


gulp.task('cssmin', function () {
    return gulp.src('output/css/*.css')
        .pipe(cssmin())
        .pipe(gulp.dest('output/css'))
});

gulp.task('cssconcat',function () {
    return gulp.src('src/css/*.css')
        .pipe(concat('all.css'))//合并后的文件名
        .pipe(gulp.dest('output/css'));
});

gulp.task('cssconcat-dev',function () {
    return gulp.src('src/css/*.css')
        .pipe(concat('all.css'))//合并后的文件名
        .pipe(gulp.dest('src/assets/css'));
});

gulp.task('cssRev', function () {
    return gulp.src(['output/css/*.css','output/js/*.js'])
        .pipe(gulp.dest('output/'))
        .pipe(rev())
        .pipe(gulp.dest('output/assets'))
        .pipe(rev.manifest())
        .pipe(gulp.dest('output/rev'));
});

gulp.task('movejs', function(){
  return gulp.src('output/assets/*.js')
  .pipe(gulp.dest('dist/assets/js/'));
});

gulp.task('movecss', function(){
  return gulp.src('output/assets/*.css')
  .pipe(gulp.dest('dist/assets/css/'));
});



gulp.task('htmlmin', function () {
    var options = {
        removeComments: false,//清除HTML注释
        collapseWhitespace: false,//压缩HTML
        collapseBooleanAttributes: true,//省略布尔属性的值 <input checked="true"/> ==> <input />
        removeEmptyAttributes: true,//删除所有空格作属性值 <input id="" /> ==> <input />
        removeScriptTypeAttributes: true,//删除<script>的type="text/javascript"
        removeStyleLinkTypeAttributes: true,//删除<style>和<link>的type="text/css"
        minifyJS: true,//压缩页面JS
        minifyCSS: true//压缩页面CSS
    };
    return gulp.src('dist/*.html')
        .pipe(htmlmin(options))
        .pipe(gulp.dest('dist/'));
});

// gulp.task('rev',function(){
//     gulp.src('src/*.html')
//         .pipe(rev())
//         .pipe(gulp.dest('dist/'));
       
// })

gulp.task('rev', function () {
    gulp.src(['output/rev/*.json','src/*.html'])
        .pipe( revCollector({
            
            
        }) )
        .pipe( gulp.dest('dist/') );
});

gulp.task('less', function () {
    return gulp.src('src/less/*.less')
        .pipe(less())
        .pipe(gulp.dest('src/css'));
});

var filesToMove = [
    'src/images/**/*.*'
];

gulp.task('dist', function () {
    return gulp.src(filesToMove)
        .pipe(gulp.dest('dist/assets/images'));
});

gulp.task('dist-dev', function () {
    return gulp.src(filesToMove)
        .pipe(gulp.dest('src/assets/images'));
});

gulp.task('replace', function(){
    return gulp.src('dist/*.html')
        .pipe(replace('src="images/','src="assets/images/'))
        .pipe(gulp.dest('dist/'));
});

gulp.task('distres', function () {
    return gulp.src('src/resources/**.*')
        .pipe(gulp.dest('dist/resource'))
});

gulp.task('AutoFx', function () {
    return gulp.src('dist/css/*.css')
        .pipe(autoprefixer({
            browsers: ['last 2 versions','Android >= 4.0'],
            cascade: true, //是否美化属性值 默认：true 像这样：
            //-webkit-transform: rotate(45deg);
            //        transform: rotate(45deg);
            remove:true //是否去掉不必要的前缀 默认：true 
        }))
        .pipe(gulp.dest('dist/css'));
});

//reload server
gulp.task('reload-dev',function() {
  return gulp.src('src/**/*.*')
    .pipe(connect.reload());
});

gulp.task('connectDev', function() {
  connect.server({
    root: 'src',
    port: 8000,
    livereload: true
  });
});

//gulp.task('build', ['clean','jsconcat','jsmin']);

gulp.task('build', gulpSequence('clean','jsconcat','jsmin','cssconcat','cssmin','cssRev','movejs','movecss','AutoFx',['dist','distres','rev'],'htmlmin','replace'));

//gulp.task('dev', ['connectDev', 'watch','less']);

// gulp.task('dev', gulpSequence('clean','jsconcat','cssconcat','cssRev',['dist','rev'],'connectDev', 'watch'));

gulp.task('dev-re',function(callback){
     gulpSequence('less','jsconcat-dev','cssconcat-dev','dist-dev')(callback);
})

gulp.task('default', ['build']);

// gulp.task('watch', function() {
//     gulp.watch(path.src + '**/*.*',['dev-re','rev','less','reload-dev']);
// });

gulp.task('dev', ['connectDev', 'watch','less','jsconcat-dev','cssconcat-dev','dist-dev']);

gulp.task('watch', function() {
    gulp.watch(path.src + '**/*.*',['reload-dev','dev-re']);
});
